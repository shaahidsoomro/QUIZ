
# PakStudy Quiz Manager – User Guide

**Plugin Version:** 1.0  
**Author:** Shahid Hussain Soomro  
**Website:** [PakStudy.XYZ](https://pakstudy.xyz)  

---

## 📦 Overview

PakStudy Quiz Manager is a complete WordPress plugin designed to manage, display, and track Pakistan Studies quizzes. It supports:

- MCQs with 4 options and one correct answer
- Categories for organizing quizzes
- CSV import/export
- User attempt tracking
- Explanation for each MCQ
- Instant feedback for logged-in users

---

## 🧰 Features

| Feature                         | Description                                                              |
|---------------------------------|--------------------------------------------------------------------------|
| MCQ Post Type                   | Custom post type `mcq` with title, question, options, correct answer    |
| Category Support                | Organize MCQs using `mcq_category` taxonomy                             |
| Frontend Quiz Shortcode        | Use `[pakstudy_quiz limit="5" difficulty="Easy"]`                        |
| User Feedback                  | Instant correct/incorrect answer feedback (login required)              |
| Explanation Support            | Show explanation after each answer (for logged-in users)                |
| Attempt Tracking               | Tracks who attempted what and when (admin only)                         |
| Import/Export                  | Upload MCQs via CSV in admin panel                                      |

---

## 📥 Installation

1. Download and install the plugin via WordPress Admin → Plugins → Upload Plugin.
2. Activate the plugin.
3. Go to **Settings > Permalinks** and click "Save Changes" to flush rewrite rules.

---

## 📝 Creating MCQs

1. Go to **MCQs > Add New**
2. Enter:
   - Post Title
   - Question Text
   - Options A to D
   - Select Correct Option (a/b/c/d)
   - Difficulty
   - Explanation (optional but recommended)
3. Click **Publish**

---

## ⛏️ Shortcode Usage

Add the following shortcode to any post/page:

```plaintext
[pakstudy_quiz limit="5" difficulty="Medium"]
```

- `limit`: number of questions
- `difficulty`: Easy, Medium, or Hard

---

## 🔐 User Experience

| Logged-In User | Guest User |
|----------------|------------|
| Sees full feedback ✔✖ + explanation | Prompted to log in to view answers |

---

## 📊 Admin Reports

1. Go to **MCQs > MCQ Reports**
2. See user attempts: who answered which question, result, and timestamp

---

## 📁 CSV Import

CSV Columns must be:
```
question_text,option_a,option_b,option_c,option_d,correct_option,difficulty,explanation
```

Upload via **MCQs > Import MCQs**

---

## 📚 Support

For documentation or help, visit:  
📩 [https://pakstudy.xyz](https://pakstudy.xyz)  
📧 Email: shahid@pakstudy.xyz

