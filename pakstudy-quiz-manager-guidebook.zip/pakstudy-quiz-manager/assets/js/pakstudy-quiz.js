
jQuery(document).ready(function($) {
    $('#pakstudy-quiz-form').on('submit', function(e) {
        e.preventDefault();
        $('.pakstudy-question-block').each(function() {
            var block = $(this);
            var correct = block.data('correct');
            var explanation = block.data('explanation');
            var selected = block.find('input[type=radio]:checked').val();
            var feedback = block.find('.pakstudy-feedback');
            var explanationBox = block.find('.pakstudy-explanation');

            if (!selected) {
                feedback.html('<span style="color:orange">Please select an option.</span>').show();
                explanationBox.hide();
            } else if (!pakstudy_ajax.is_logged_in) {
                feedback.html('<span style="color:red">Login to view the correct answer.</span>').show();
                explanationBox.hide();
            } else if (selected === correct) {
                feedback.html('<span style="color:green">✔ Correct</span>').show();
                explanationBox.html('<strong>Explanation:</strong> ' + explanation).show();
            } else {
                feedback.html('<span style="color:red">✖ Incorrect. Correct Answer: ' + correct.toUpperCase() + '</span>').show();
                explanationBox.html('<strong>Explanation:</strong> ' + explanation).show();
            }
        });
    });
});
