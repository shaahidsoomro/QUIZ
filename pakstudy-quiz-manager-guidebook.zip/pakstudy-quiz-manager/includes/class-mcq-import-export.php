<?php
class MCQ_Import_Export {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_post_import_mcqs', [$this, 'handle_import']);
    }

    public function add_menu() {
        add_submenu_page(
            'edit.php?post_type=mcq',
            'Import MCQs',
            'Import MCQs',
            'manage_options',
            'import-mcqs',
            [$this, 'import_page']
        );
    }

    public function import_page() {
        ?>
        <div class="wrap">
            <h1>Import MCQs (CSV)</h1>
            <form method="post" action="<?php echo admin_url('admin-post.php'); ?>" enctype="multipart/form-data">
                <input type="hidden" name="action" value="import_mcqs">
                <?php wp_nonce_field('import_mcqs_nonce'); ?>
                <input type="file" name="mcq_csv" accept=".csv" required>
                <input type="submit" value="Import" class="button button-primary">
            </form>
        </div>
        <?php
    }

    public function handle_import() {
        if (!current_user_can('manage_options') || !check_admin_referer('import_mcqs_nonce')) {
            wp_die('Unauthorized or invalid request.');
        }

        if (!isset($_FILES['mcq_csv']) || $_FILES['mcq_csv']['error'] !== UPLOAD_ERR_OK) {
            wp_die('CSV upload failed.');
        }

        $csv = array_map('str_getcsv', file($_FILES['mcq_csv']['tmp_name']));
        $headers = array_map('trim', array_shift($csv));

        foreach ($csv as $row) {
            $data = array_combine($headers, $row);
            $post_id = wp_insert_post([
                'post_type' => 'mcq',
                'post_title' => wp_strip_all_tags($data['question_text']),
                'post_content' => $data['question_text'],
                'post_status' => 'publish',
            ]);

            if ($post_id) {
                foreach (['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option', 'difficulty', 'meta_title', 'meta_description'] as $field) {
                    update_post_meta($post_id, $field, sanitize_text_field($data[$field] ?? ''));
                }
            }
        }

        wp_redirect(admin_url('edit.php?post_type=mcq'));
        exit;
    }
}
?>
