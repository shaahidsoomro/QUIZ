<?php
class MCQ_Reporting {
    public function __construct() {
        add_action('admin_menu', [$this, 'add_report_menu']);
    }

    public function add_report_menu() {
        add_submenu_page(
            'edit.php?post_type=mcq',
            'MCQ Attempt Reports',
            'MCQ Reports',
            'manage_options',
            'mcq-reports',
            [$this, 'render_report_page']
        );
    }

    public function render_report_page() {
        global $wpdb;
        $table = $wpdb->prefix . 'mcq_attempts';

        $results = $wpdb->get_results("
            SELECT a.*, u.display_name, p.post_title
            FROM {$table} a
            LEFT JOIN {$wpdb->users} u ON a.user_id = u.ID
            LEFT JOIN {$wpdb->posts} p ON a.mcq_id = p.ID
            ORDER BY attempted_at DESC
            LIMIT 100
        ");

        echo '<div class="wrap"><h1>MCQ Attempt Reports</h1>';
        echo '<table class="widefat striped"><thead><tr>
            <th>User</th><th>MCQ</th><th>Selected</th><th>Correct</th>
            <th>Result</th><th>Date</th></tr></thead><tbody>';
        foreach ($results as $row) {
            echo "<tr>
                <td>{$row->display_name}</td>
                <td><a href='" . get_edit_post_link($row->mcq_id) . "'>{$row->post_title}</a></td>
                <td>{$row->selected_option}</td>
                <td>{$row->correct_option}</td>
                <td>" . ($row->is_correct ? '<span style="color:green">✔</span>' : '<span style="color:red">✖</span>') . "</td>
                <td>{$row->attempted_at}</td>
            </tr>";
        }
        echo '</tbody></table></div>';
    }
}
?>
