<?php
class MCQ_Taxonomy {
    public function __construct() {
        add_action('init', [$this, 'register_taxonomy']);
    }

    public function register_taxonomy() {
        register_taxonomy('mcq_category', 'mcq', [
            'labels' => [
                'name'              => 'MCQ Categories',
                'singular_name'     => 'MCQ Category',
                'search_items'      => 'Search MCQ Categories',
                'all_items'         => 'All Categories',
                'parent_item'       => 'Parent Category',
                'parent_item_colon' => 'Parent Category:',
                'edit_item'         => 'Edit Category',
                'update_item'       => 'Update Category',
                'add_new_item'      => 'Add New Category',
                'new_item_name'     => 'New Category Name',
                'menu_name'         => 'MCQ Categories',
            ],
            'hierarchical'      => true,
            'show_ui'           => true,
            'show_admin_column' => true,
            'rewrite'           => ['slug' => 'mcq-category'],
            'show_in_rest'      => true
        ]);
    }
}
?>
