<?php
class MCQ_Content_Display {
    public function __construct() {
        add_filter('the_content', [$this, 'inject_mcq_fields']);
    }

    public function inject_mcq_fields($content) {
        if (get_post_type() !== 'mcq') return $content;

        $question = get_post_meta(get_the_ID(), 'question_text', true);
        $options = '';
        foreach (['a', 'b', 'c', 'd'] as $opt) {
            $value = get_post_meta(get_the_ID(), "option_{$opt}", true);
            $options .= "<li><strong>" . strtoupper($opt) . ":</strong> " . esc_html($value) . "</li>";
        }

        $injected = "<div class='mcq-question'><strong>Question:</strong> {$question}</div>
                     <ul class='mcq-options'>{$options}</ul>";

        return $injected . $content;
    }
}
?>
