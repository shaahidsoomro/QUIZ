<?php
class MCQ_Post_Type {
    public function __construct() {
        add_action('init', [$this, 'register_mcq_post_type']);
    }

    public function register_mcq_post_type() {
        register_post_type('mcq', [
            'labels' => [
                'name' => 'MCQs',
                'singular_name' => 'MCQ',
            ],
            'public' => true,
            'has_archive' => true,
            'rewrite' => ['slug' => 'mcq'],
            'supports' => ['title', 'editor', 'custom-fields'],
            'menu_icon' => 'dashicons-welcome-learn-more',
        ]);
    }
}
?>
