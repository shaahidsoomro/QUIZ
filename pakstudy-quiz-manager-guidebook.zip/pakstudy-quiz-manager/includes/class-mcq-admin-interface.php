<?php
class MCQ_Admin_Interface {
    public function __construct() {
        add_filter('manage_mcq_posts_columns', [$this, 'add_columns']);
        add_action('manage_mcq_posts_custom_column', [$this, 'render_columns'], 10, 2);
        add_filter('manage_edit-mcq_sortable_columns', [$this, 'make_columns_sortable']);
        add_action('restrict_manage_posts', [$this, 'filter_dropdown']);
        add_filter('parse_query', [$this, 'filter_query']);
    }

    public function add_columns($columns) {
        $columns['correct_option'] = 'Correct Option';
        $columns['difficulty'] = 'Difficulty';
        return $columns;
    }

    public function render_columns($column, $post_id) {
        if ($column == 'correct_option') {
            echo esc_html(get_post_meta($post_id, 'correct_option', true));
        } elseif ($column == 'difficulty') {
            echo esc_html(get_post_meta($post_id, 'difficulty', true));
        }
    }

    public function make_columns_sortable($columns) {
        $columns['difficulty'] = 'difficulty';
        return $columns;
    }

    public function filter_dropdown() {
        global $typenow;
        if ($typenow == 'mcq') {
            $current = $_GET['difficulty_filter'] ?? '';
            ?>
            <select name="difficulty_filter">
                <option value="">All Difficulties</option>
                <?php foreach (['Easy', 'Medium', 'Hard'] as $level): ?>
                    <option value="<?php echo $level; ?>" <?php selected($current, $level); ?>><?php echo $level; ?></option>
                <?php endforeach; ?>
            </select>
            <?php
        }
    }

    public function filter_query($query) {
        global $pagenow;
        $post_type = $_GET['post_type'] ?? '';
        $difficulty = $_GET['difficulty_filter'] ?? '';

        if ($post_type == 'mcq' && $pagenow == 'edit.php' && $difficulty) {
            $query->query_vars['meta_key'] = 'difficulty';
            $query->query_vars['meta_value'] = $difficulty;
        }
    }
}
?>
