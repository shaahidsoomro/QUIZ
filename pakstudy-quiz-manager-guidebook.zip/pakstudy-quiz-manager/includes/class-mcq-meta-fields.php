<?php
class MCQ_Meta_Fields {
    public function __construct() {
        add_action('add_meta_boxes', [$this, 'add_meta_boxes']);
        add_action('save_post', [$this, 'save_meta_boxes']);
    }

    public function add_meta_boxes() {
        add_meta_box('mcq_meta_box', 'MCQ Details', [$this, 'render_meta_box'], 'mcq', 'normal', 'high');
    }

    public function render_meta_box($post) {
        $fields = ['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option', 'difficulty', 'explanation'];
        foreach ($fields as $field) {
            $$field = get_post_meta($post->ID, $field, true);
        }
        ?>
        <label><strong>Question Text:</strong></label><br>
        <textarea name="question_text" style="width:100%" required><?php echo esc_textarea($question_text); ?></textarea><br><br>
        <?php foreach (['a', 'b', 'c', 'd'] as $opt): ?>
            <label><strong>Option <?php echo strtoupper($opt); ?>:</strong></label><br>
            <input type="text" name="option_<?php echo $opt; ?>" value="<?php echo esc_attr(${'option_'.$opt}); ?>" style="width:100%" required><br><br>
        <?php endforeach; ?>
        <label><strong>Correct Option (a/b/c/d):</strong></label><br>
        <select name="correct_option" required>
            <option value="">Select Correct Option</option>
            <?php foreach (['a', 'b', 'c', 'd'] as $opt): ?>
                <option value="<?php echo $opt; ?>" <?php selected($correct_option, $opt); ?>><?php echo strtoupper($opt); ?></option>
            <?php endforeach; ?>
        </select><br><br>
        <label><strong>Difficulty:</strong></label><br>
        <select name="difficulty" required>
            <?php foreach (['Easy', 'Medium', 'Hard'] as $level): ?>
                <option value="<?php echo $level; ?>" <?php selected($difficulty, $level); ?>><?php echo $level; ?></option>
            <?php endforeach; ?>
        </select><br><br>
        <label><strong>Explanation:</strong></label><br>
        <textarea name="explanation" style="width:100%" rows="3"><?php echo esc_textarea($explanation); ?></textarea><br><br>
        <?php
    }

    public function save_meta_boxes($post_id) {
        if (!isset($_POST['correct_option']) || !in_array($_POST['correct_option'], ['a', 'b', 'c', 'd'])) {
            return;
        }

        $fields = ['question_text', 'option_a', 'option_b', 'option_c', 'option_d', 'correct_option', 'difficulty', 'explanation'];
        foreach ($fields as $field) {
            if (isset($_POST[$field])) {
                update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
            }
        }
    }
}
?>
