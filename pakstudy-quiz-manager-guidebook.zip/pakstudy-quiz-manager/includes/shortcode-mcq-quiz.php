<?php
add_shortcode('pakstudy_quiz', 'pakstudy_render_quiz');

function pakstudy_render_quiz($atts) {
    add_action('wp_enqueue_scripts', 'pakstudy_enqueue_quiz_styles');
    wp_enqueue_script('pakstudy-quiz-js', plugin_dir_url(__FILE__) . '../assets/js/pakstudy-quiz.js', ['jquery'], null, true);
    wp_localize_script('pakstudy-quiz-js', 'pakstudy_ajax', [
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('pakstudy_quiz_nonce'),
        'is_logged_in' => is_user_logged_in()
    ]);

    if (!is_user_logged_in()) {
        return '<p style="color:red; font-weight:bold;">Please <a href="' . wp_login_url(get_permalink()) . '">log in</a> to view the correct answers and explanations.</p>';
    }

    $atts = shortcode_atts([
        'category' => '',
        'difficulty' => '',
        'limit' => 5
    ], $atts);

    $args = [
        'post_type' => 'mcq',
        'posts_per_page' => intval($atts['limit']),
        'orderby' => 'rand',
        'meta_query' => []
    ];

    if (!empty($atts['difficulty'])) {
        $args['meta_query'][] = [
            'key' => 'difficulty',
            'value' => $atts['difficulty'],
            'compare' => '='
        ];
    }

    $query = new WP_Query($args);
    if (!$query->have_posts()) {
        return '<p>No MCQs found.</p>';
    }

    ob_start();
    echo '<form id="pakstudy-quiz-form" class="pakstudy-quiz">';
    $index = 1;
    while ($query->have_posts()) {
        $query->the_post();
        $post_id = get_the_ID();
        $question = get_post_meta($post_id, 'question_text', true);
        $correct = get_post_meta($post_id, 'correct_option', true);
        $explanation = get_post_meta($post_id, 'explanation', true);
        $options = [
            'a' => get_post_meta($post_id, 'option_a', true),
            'b' => get_post_meta($post_id, 'option_b', true),
            'c' => get_post_meta($post_id, 'option_c', true),
            'd' => get_post_meta($post_id, 'option_d', true)
        ];

        echo "<div class='pakstudy-question-block' data-correct='{$correct}' data-mcq-id='{$post_id}' data-explanation="" . esc_attr($explanation) . "">";
        echo "<p><strong>Q{$index}:</strong> " . esc_html($question) . "</p>";
        foreach ($options as $key => $value) {
            echo "<label class='pakstudy-option'>
                    <input type='radio' name='q{$post_id}' value='{$key}'> " . esc_html($value) . "
                  </label><br>";
        }
        echo "<div class='pakstudy-feedback' style='display:none'></div>";
        echo "<div class='pakstudy-explanation' style='display:none; margin-top: 10px; color: #555;'></div>";
        echo "</div><hr>";
        $index++;
    }
    wp_reset_postdata();
    echo '<button type="submit" class="pakstudy-submit">Submit Quiz</button>';
    echo '</form>';

    return ob_get_clean();
}
?>
